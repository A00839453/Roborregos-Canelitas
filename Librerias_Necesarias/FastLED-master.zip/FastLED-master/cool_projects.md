  * Advanced Color Gradient using online version of FastLED.
    * https://wokwi.com/projects/285170662915441160
  * LedMapper tool for irregular shapes
    * https://github.com/jasoncoon/led-mapper
  * list of projects on reddit:
    * https://www.reddit.com/r/FastLED/wiki/index/user_examples/
  * mesh networked esp32 with mutli wifi connections for redundancy
