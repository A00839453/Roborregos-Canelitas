// this will get stripped out but it's good to ensure that the code that we have is compiling as expected.

#ifdef __EMSCRIPTEN__
#include "button.hpp"
#include "slider.hpp"
#include "checkbox.hpp"
#include "ui_manager.hpp"
#include "ui_internal.hpp"
#include "ui_canvas_size.hpp"
#include "engine_events.hpp"
#include "setup_and_loop.hpp"
#include "ui_number_field.hpp"
#endif
