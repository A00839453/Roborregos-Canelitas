#pragma once



#ifndef __EMSCRIPTEN__
#error "This file should only be included in an Emscripten build"
#endif

#include "timer.hpp"
#include "ui/link.hpp"